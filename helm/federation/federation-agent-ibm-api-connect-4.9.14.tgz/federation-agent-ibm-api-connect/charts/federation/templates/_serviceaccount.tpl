{{- define "agent.serviceAccount" -}}
{{- if or (not .Values.kubernetes.serviceAccount.managed) (and .Values.kubernetes.serviceAccount.managed .Values.kubernetes.serviceAccount.name) }}
{{- .Values.kubernetes.serviceAccount.name -}}
{{- else }}
{{- $name := default .Chart.Name .Values.kubernetes.nameOverride -}}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" -}}
{{- end -}}
{{- end -}}

{{- define "federation.serviceaccount.tpl" -}}
{{- if .Values.kubernetes.serviceAccount.managed }}
apiVersion: v1
kind: ServiceAccount
metadata:
  name: {{ template "agent.serviceAccount" . }}
  labels: {{- include "common.labels" . }}
{{- end -}}
{{- end}}
