{{- define "federation.configmap.tpl" -}}

{{- $baseHttpConfig := include "common.core.http" . | fromYaml -}}
{{- $overrideServices := .Values.config.graviteeYml.services | default dict -}}
{{- $overrideServicesCore := $overrideServices.core | default dict -}}
{{- $overrideServicesCoreHttp := $overrideServicesCore.http | default dict -}}
{{- $mergedCoreHttpConfig := merge $baseHttpConfig $overrideServicesCoreHttp -}}

{{- $baseLoggingConfig := include "common.logging" . | fromYaml -}}
{{- $overrideLoggingCOnfig := .Values.config.logging | default dict -}}
{{- $mergedLoggingConfig := merge $baseLoggingConfig $overrideLoggingCOnfig -}}

apiVersion: v1
kind: ConfigMap
metadata:
  name: {{ include "common.name" . }}
  labels: {{- include "common.labels" . }}
data:
  gravitee.yml: |
    secrets:
      kubernetes:
        enabled: true
    services:
      core:
        http: {{ toYaml $mergedCoreHttpConfig | nindent 10 }}

  gravitee-override.yml: |{{ toYaml .Values.config.graviteeYml | nindent 4 }}
  logback.xml: |
    <?xml version="1.0" encoding="UTF-8"?>
      <configuration>
          <appender name="STDOUT" class="ch.qos.logback.core.ConsoleAppender">
              {{- if $mergedLoggingConfig.json }}
              <encoder class="ch.qos.logback.core.encoder.LayoutWrappingEncoder">
                  <layout class="ch.qos.logback.contrib.json.classic.JsonLayout">
                      <jsonFormatter
                              class="ch.qos.logback.contrib.jackson.JacksonJsonFormatter">
                      </jsonFormatter>
                      <appendLineSeparator>true</appendLineSeparator>
                      <timestampFormat>yyyy-MM-dd'T'HH:mm:ss.SSSXX</timestampFormat>
                  </layout>
              </encoder>
              {{- else }}
              <encoder>
                  <pattern>{{ $mergedLoggingConfig.encoderPattern }}</pattern>
              </encoder>
               {{- end }}
          </appender>

          <logger name="io.gravitee" level="{{ $mergedLoggingConfig.graviteeLevel }}" />
          <logger name="org.eclipse.jetty" level="{{ $mergedLoggingConfig.jettyLevel }}" />
          {{- range $additionalLogger := $mergedLoggingConfig.additionalLoggers }}
          <logger name="{{ $additionalLogger.name }}" level="{{ $additionalLogger.level }}" />
          {{- end }}

          <root level="WARN">
              <appender-ref ref="STDOUT" />
          </root>
      </configuration>
{{- end -}}
