{{- define "common.name" -}}
{{- default .Chart.Name .Values.kubernetes.nameOverride | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{- define "common.labels" }}
    app: {{ (include "common.name" .) }}
    app.kubernetes.io/name: {{ (include "common.name" .) }}
    app.kubernetes.io/instance: {{ .Release.Name }}
    app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
    app.kubernetes.io/component: "federation-agent"
    app.kubernetes.io/managed-by: {{ .Release.Service }}
    helm.sh/chart: {{ .Chart.Name }}-{{ .Chart.Version | replace "+" "_" }}
{{- end}}

{{- define "common.core.http" -}}
enabled: true
port: 18084
host: 0.0.0.0
authentication:
    type: basic
    users:
      admin: adminadmin
{{- end -}}

{{- define "common.logging" -}}
json: true
encoderPattern: "%d{HH:mm:ss.SSS} [%thread] %-5level %logger{36} - %msg%n"
graviteeLevel: INFO
jettyLevel: INFO
additionalLoggers: []
{{- end -}}
