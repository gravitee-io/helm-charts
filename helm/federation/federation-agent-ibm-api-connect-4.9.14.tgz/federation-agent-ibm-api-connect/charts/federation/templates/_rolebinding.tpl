{{- define "federation.rolebinding.tpl" -}}
{{- if .Values.kubernetes.serviceAccount.managed }}
apiVersion: rbac.authorization.k8s.io/v1
kind: RoleBinding
metadata:
  name: {{ template "agent.serviceAccount" . }}-role-binding
  labels: {{- include "common.labels" . }}
roleRef:
  kind: Role
  name: {{ template "agent.serviceAccount" . }}-role
  apiGroup: rbac.authorization.k8s.io
subjects:
- kind: ServiceAccount
  name: {{ template "agent.serviceAccount" . }}
  namespace: {{ .Release.Namespace | quote }}
{{- end -}}
{{- end -}}
