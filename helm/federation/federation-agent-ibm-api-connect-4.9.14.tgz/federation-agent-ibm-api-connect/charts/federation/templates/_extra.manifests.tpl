{{- define "extra.manifest.tpl" }}
{{ range .Values.kubernetes.extraObjects }}
---
{{ if typeIs "string" . }}
  {{- tpl . $ }}
{{- else }}
  {{- tpl (toYaml .) $ }}
{{- end }}
{{ end }}
{{- end }}
