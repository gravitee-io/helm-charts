{{- define "federation.deployment.tpl" -}}
{{- $configDir := "/opt/graviteeio-federation-agent/config" -}}
{{- $imageName := (default .Chart.Name .Values.kubernetes.deployment.image.name) -}}
{{- $image := printf "%s:%s" $imageName (.Values.kubernetes.deployment.image.tag | default .Chart.AppVersion) -}}
{{- if and (hasKey .Values.kubernetes.deployment.image "repository") (not (empty .Values.kubernetes.deployment.image.repository)) }}
{{- $image = printf "%s/%s" .Values.kubernetes.deployment.image.repository $image -}}
{{- end }}
{{- $basicCredentials := ""}}

{{- $baseHttpConfig := include "common.core.http" . | fromYaml -}}
{{- $overrideServices := .Values.config.graviteeYml.services | default dict -}}
{{- $overrideServicesCore := $overrideServices.core | default dict -}}
{{- $overrideServicesCoreHttp := $overrideServicesCore.http | default dict -}}
{{- $mergedConfig := merge $baseHttpConfig $overrideServicesCoreHttp -}}
{{- $coreHttpEnabled := $mergedConfig.enabled -}}
{{- $coreHttpPort := $mergedConfig.port -}}
{{- $coreHttpAuthentication := $mergedConfig.authentication -}}

apiVersion: apps/v1
kind: Deployment
metadata:
  name: {{ include "common.name" . }}
  labels: {{- include "common.labels" . }}
spec:
  replicas: 1
  selector:
    matchLabels:
      app: {{ include "common.name" . }}
  template:
    metadata:
      annotations:
        checksum/config: {{ include (print $.Template.BasePath "/configmap.yaml") . | sha256sum }}
      labels:
        app: {{ include "common.name" . }}
    spec:
      serviceAccountName: {{ include "agent.serviceAccount" . }}
      {{- if .Values.kubernetes.deployment.image.pullSecretsRef }}
      imagePullSecrets:
        - name: {{ .Values.kubernetes.deployment.image.pullSecretsRef }}
      {{- end }}
      containers:
        - image: {{ $image }}
          name: {{ include "common.name" . }}
          env:
          - name: JDK_JAVA_OPTIONS
            value: -Dgravitee.conf={{ $configDir }}/gravitee.yml,{{ $configDir }}/gravitee-override.yml
{{- if .Values.kubernetes.deployment.extraEnvs }}
{{ toYaml ( .Values.kubernetes.deployment.extraEnvs ) | indent 12 }}
{{- end }}
          volumeMounts:
            - name: gravitee-config
              mountPath: {{ $configDir }}
          {{- with .Values.kubernetes.deployment.extraVolumeMounts }}
          {{- tpl . $ | nindent 12 }}
          {{- end }}
          ports:
            - containerPort: {{$coreHttpPort}}
          {{- if $coreHttpEnabled }}
          {{- with $coreHttpAuthentication -}}
          {{- if and (eq .type "basic") (gt (len .users) 0) -}}
          {{- $user := index (keys .users) 0 -}}
          {{- $basicCredentials = printf "Basic %s" ( b64enc (printf "%s:%s" $user (index .users $user))) -}}
          {{- end -}}
          {{- end }}
          startupProbe:
            initialDelaySeconds: 10
            periodSeconds: 10
            timeoutSeconds: 1
            successThreshold: 1
            failureThreshold: 29
            httpGet:
              path: /_node/health
              scheme: HTTP
              port: {{ $coreHttpPort }}
              {{- if not (empty $basicCredentials) }}
              httpHeaders:
                - name: Authorization
                  value: {{ $basicCredentials }}
              {{- end }}
          readinessProbe:
            periodSeconds: 10
            timeoutSeconds: 2
            successThreshold: 1
            failureThreshold: 2
            httpGet:
              path: /_node/health
              scheme: HTTP
              port: {{ $coreHttpPort }}
              {{- if not (empty $basicCredentials) }}
              httpHeaders:
                - name: Authorization
                  value: {{ $basicCredentials }}
              {{- end }}
          livenessProbe:
            periodSeconds: 15
            timeoutSeconds: 2
            successThreshold: 1
            failureThreshold: 3
            httpGet:
              path: /_node/health
              scheme: HTTP
              port: {{ $coreHttpPort }}
              {{- if not (empty $basicCredentials) }}
              httpHeaders:
                - name: Authorization
                  value: {{ $basicCredentials }}
              {{- end }}
          {{- end }}

      volumes:
        - name: gravitee-config
          configMap:
            name: {{ include "common.name" . }}
            items:
              - key: gravitee.yml
                path: gravitee.yml
              - key: gravitee-override.yml
                path: gravitee-override.yml
              - key: logback.xml
                path: logback.xml
        {{- with .Values.kubernetes.extraVolumes }}
        {{- tpl . $ | nindent 8 }}
        {{- end }}
{{- end -}}
