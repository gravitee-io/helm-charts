{{- define "federation.role.tpl" -}}
{{- if .Values.kubernetes.serviceAccount.managed }}
apiVersion: rbac.authorization.k8s.io/v1
kind: Role
metadata:
  name: {{ template "agent.serviceAccount" . }}-role
  labels: {{- include "common.labels" . }}
rules: {{ toYaml .Values.kubernetes.serviceAccount.roleRules | nindent 2 -}}
{{- end -}}
{{- end -}}
